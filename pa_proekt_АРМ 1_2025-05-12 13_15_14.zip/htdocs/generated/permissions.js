'use strict';
 export class Permissions { 
 static get globalPermissions () { 
 return {
  "ActuatorsСontrol": {
    "displayName": "Управление исполнительными механизмами",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "CallProgram": {
    "displayName": "Вызов программы",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "ChangeSetpoints": {
    "displayName": "Задание уставок",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "ChangeSettings": {
    "displayName": "Изменение настроек",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "Control": {
    "displayName": "Управление",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "DataTableEdit": {
    "displayName": "Редактирование ячеек таблицы",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "DataTableFilter": {
    "displayName": "Использование фильтров в таблице",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "DirectoryAdd": {
    "displayName": "Добавление записи справочника",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "DirectoryDelete": {
    "displayName": "Удаление записи справочника",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "DirectoryEdit": {
    "displayName": "Редактирование записи справочника",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "DirectoryFilter": {
    "displayName": "Использование фильтров в справочнике",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "IntervalsSettings": {
    "displayName": "Настройка интервалов",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "JournalAck": {
    "displayName": "Квитирование сообщения",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "JournalGroupAck": {
    "displayName": "Групповое квитирование сообщений",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "JournalPrint": {
    "displayName": "Печать сообщений",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "JournalSave": {
    "displayName": "Экспорт сообщений",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "JournalUseFilters": {
    "displayName": "Использование фильтров в журнале",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "Login": {
    "displayName": "Вход в систему",
    "requirePassword": false,
    "rights": {
      "_All": 9
    }
  },
  "OpenWindow": {
    "displayName": "Открытие окна",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "PenGroupsCreate": {
    "displayName": "Создание групп перьев",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "ReadUsers": {
    "displayName": "Чтение пользователей",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "ReadValue": {
    "displayName": "Чтение значения",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "StandardIntervalsSelect": {
    "displayName": "Выбор стандартных интервалов",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "TrendAddPens": {
    "displayName": "Изменение состава перьев",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "TrendChangePens": {
    "displayName": "Изменение настройки перьев",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "TrendPrint": {
    "displayName": "Печать графика",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "TrendSave": {
    "displayName": "Экспорт графика",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  },
  "WriteValue": {
    "displayName": "Запись значения",
    "requirePassword": false,
    "rights": {
      "_All": 1
    }
  }
} 
 }
 static get objectsPermissions () { 
 return {
  "59449": {
    "parentId": 87
  }
} 
 }
 static get logActionTry () { 
 return {
  "_All": false
} 
 }
}