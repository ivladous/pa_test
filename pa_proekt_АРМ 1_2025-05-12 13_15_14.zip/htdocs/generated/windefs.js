'use strict';
export class WinDefs {
static get startWindow() {
    return {"58048":"59458"};
} 
static get mainFrame() { 
    return {"58048":"58061"};
}
constructor(){
this.obj={}
 
this.winDef={
'58048':{
'id':'58048',
'template':'t_58048',
'typeid':'58048',
'elname':'Шаблон экрана 1',
'objectid':'58046',
'width':"1920",
'height':"1080",
'bordercolor':"rgb(128,128,128)",
},
'59458':{
'id':'59458',
'template':'t_59458',
'typeid':'59458',
'elname':'Окно 1',
'objectid':'59449',
'z':"0",
'width':"1920",
'height':"1080",
'bordercolor':"rgb(128,128,128)",
'hideifdenycontrol':"false",
'tabindex':"0",
'mousecursorkind':"0",
},

}
this.winMap={
  "58046": {
    "Шаблон экрана 1": "58048"
  },
  "59449": {
    "Окно 1": "59458"
  }
}
}
}