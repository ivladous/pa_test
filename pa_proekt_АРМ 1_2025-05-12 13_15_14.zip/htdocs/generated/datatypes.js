'use strict';
 export class DataTypes { 
 static get dataTypes() { 
 return {
  "Локальная.array_last_values": {
    "TypeOfElementsName": "LREAL",
    "Subranges": [
      5
    ],
    "DataType": "ArrayType"
  },
  "Локальная.struct_patest": {
    "Fields": {
      "id": "INT",
      "name": "STRING"
    },
    "DataType": "StructureType"
  },
  "Локальная.struct_patest_current_data": {
    "Fields": {
      "name": "STRING",
      "state_timestamp": "DATE_AND_TIME",
      "last_state": "BOOL",
      "value_timestamp": "DATE_AND_TIME",
      "last_value": "LREAL"
    },
    "DataType": "StructureType"
  },
  "Локальная.struct_patest_values": {
    "Fields": {
      "time": "DATE_AND_TIME",
      "value": "LREAL",
      "parameter_id": "INT",
      "id": "INT",
      "name": "STRING"
    },
    "DataType": "StructureType"
  },
  "ARRAY [*] OF Локальная.struct_patest": {
    "TypeOfElementsName": "Локальная.struct_patest",
    "Subranges": [
      0
    ],
    "DataType": "ArrayType"
  },
  "ARRAY [*] OF Локальная.struct_patest_current_data": {
    "TypeOfElementsName": "Локальная.struct_patest_current_data",
    "Subranges": [
      0
    ],
    "DataType": "ArrayType"
  },
  "ARRAY [*] OF Локальная.struct_patest_values": {
    "TypeOfElementsName": "Локальная.struct_patest_values",
    "Subranges": [
      0
    ],
    "DataType": "ArrayType"
  },
  "ARRAY [1..5] OF LREAL": {
    "TypeOfElementsName": "LREAL",
    "Subranges": [
      5
    ],
    "DataType": "ArrayType"
  },
  "ARRAY[*] OF PostgreSQL_VarsStruct": {
    "TypeOfElementsName": "PostgreSQL_VarsStruct",
    "Subranges": [
      0
    ],
    "DataType": "ArrayType"
  },
  "BOOL": {
    "DataType": "ElementaryType"
  },
  "BYTE": {
    "DataType": "ElementaryType"
  },
  "DATE_AND_TIME": {
    "DataType": "ElementaryType"
  },
  "DINT": {
    "DataType": "ElementaryType"
  },
  "HMI.BorderStyleType": {
    "Values": [
      "Solid",
      "Dash",
      "Dot",
      "None"
    ],
    "DisplayValues": [
      "Непрерывный",
      "Пунктир",
      "Точка",
      "Нет"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.ChartDisplayNameType": {
    "Values": [
      "Name",
      "Description"
    ],
    "DisplayValues": [
      "Имя",
      "Описание"
    ],
    "Indexes": [
      0,
      1
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.EventChangeType": {
    "Values": [
      "None",
      "Activated",
      "Deactivated",
      "Acknowledged"
    ],
    "DisplayValues": [
      "Нет",
      "Появление",
      "Исчезновение",
      "Квитирование"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.GradientColorType": {
    "DataType": "ElementaryType"
  },
  "HMI.HorizontalAlignType": {
    "Values": [
      "Left",
      "Center",
      "Right"
    ],
    "DisplayValues": [
      "Лево",
      "Центр",
      "Право"
    ],
    "Indexes": [
      0,
      1,
      2
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.LineJoin": {
    "Values": [
      "Line",
      "StairsUp"
    ],
    "DisplayValues": [
      "Линия",
      "Ступенька"
    ],
    "Indexes": [
      0,
      1
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.MouseCursorKinds": {
    "Values": [
      "Standard",
      "Pointer",
      "Crosshair",
      "Text",
      "NotAllowed",
      "Wait",
      "Help",
      "Move"
    ],
    "DisplayValues": [
      "Стандартный",
      "Рука",
      "Перекрестие",
      "Текст",
      "Запрет",
      "Ожидание",
      "Помощь",
      "Перемещение"
    ],
    "Indexes": [
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.OperationType": {
    "Values": [
      "Move",
      "Add",
      "Sub",
      "Mul",
      "Div"
    ],
    "DisplayValues": [
      "Присвоить",
      "Добавить",
      "Отнять",
      "Умножить",
      "Разделить"
    ],
    "Indexes": [
      0,
      1,
      2,
      3,
      4
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.PenPointType": {
    "Values": [
      "None",
      "Rect",
      "Circle",
      "Triangle",
      "Diamond",
      "Cross"
    ],
    "DisplayValues": [
      "Нет",
      "Квадрат",
      "Круг",
      "Треугольник",
      "Ромб",
      "Крест"
    ],
    "Indexes": [
      0,
      1,
      2,
      3,
      4,
      5
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.ProportionType": {
    "Values": [
      "No",
      "Width",
      "Height",
      "Min",
      "Max"
    ],
    "DisplayValues": [
      "Нет",
      "По ширине",
      "По высоте",
      "По минимальной стороне",
      "По максимальной стороне"
    ],
    "Indexes": [
      0,
      1,
      2,
      3,
      4
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.ResourceType": {
    "DataType": "ElementaryType"
  },
  "HMI.RowStyle": {
    "Fields": {
      "RowHeight": "STRING",
      "BorderThickness": "LREAL",
      "BorderColor": "HMI.SolidColorType",
      "BackgroundColor": "HMI.GradientColorType",
      "BackgroundColorEven": "HMI.GradientColorType",
      "BackgroundColorFilter": "HMI.GradientColorType",
      "FontName": "STRING",
      "FontSize": "BYTE",
      "TextColor": "HMI.SolidColorType",
      "TextColorFilter": "HMI.SolidColorType",
      "FontItalic": "BOOL",
      "FontBold": "BOOL",
      "FontUnderlined": "BOOL"
    },
    "DataType": "StructureType"
  },
  "HMI.SaveStateType": {
    "Values": [
      "Default",
      "Yes",
      "No"
    ],
    "DisplayValues": [
      "По умолчанию",
      "Да",
      "Нет"
    ],
    "Indexes": [
      0,
      1,
      2
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.SizeToContentType": {
    "Values": [
      "RealSize",
      "SetSize",
      "Crop",
      "Scroll"
    ],
    "DisplayValues": [
      "Исходный размер",
      "Подогнать",
      "Обрезать",
      "Прокрутить"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.SizeType": {
    "Values": [
      "Pixel",
      "Relative"
    ],
    "DisplayValues": [
      "Абсолютно",
      "Относительно"
    ],
    "Indexes": [
      0,
      1
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.SolidColorType": {
    "DataType": "ElementaryType"
  },
  "HMI.SortType": {
    "Values": [
      "No",
      "Asc",
      "Desc"
    ],
    "DisplayValues": [
      "Нет",
      "По возрастанию",
      "По убыванию"
    ],
    "Indexes": [
      0,
      1,
      2
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.TableColumn": {
    "Fields": {
      "DisplayName": "STRING",
      "ColumnWidth": "STRING",
      "Field": "STRING",
      "FieldType": "STRING",
      "ValueFormat": "STRING",
      "Sort": "HMI.SortType",
      "SortPosition": "BYTE",
      "Visibility": "BOOL",
      "HorizontalAlign": "HMI.HorizontalAlignType",
      "CellsStyle": "STRING",
      "EnableFilter": "BOOL",
      "DisableEdit": "BOOL",
      "VisibleOnEdit": "BOOL"
    },
    "DataType": "StructureType"
  },
  "HMI.TableColumns": {
    "TypeOfElementsName": "HMI.TableColumn",
    "Subranges": [
      0
    ],
    "DataType": "ArrayType"
  },
  "HMI.TableGridType": {
    "Values": [
      "Vertical",
      "Horizontal",
      "Both",
      "None"
    ],
    "DisplayValues": [
      "Вертикальные",
      "Горизонтальные",
      "Обе",
      "Нет"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.TileType": {
    "Values": [
      "No",
      "Tile",
      "Fill",
      "Center"
    ],
    "DisplayValues": [
      "Нет",
      "Мозаика",
      "Заполнение",
      "Центр"
    ],
    "Indexes": [
      0,
      1,
      2,
      3
    ],
    "DataType": "EnumeratedType"
  },
  "HMI.TrendPen": {
    "Fields": {
      "MinY": "LREAL",
      "MaxY": "LREAL",
      "YAxisLabel": "STRING",
      "Color": "HMI.SolidColorType",
      "LineStyle": "HMI.BorderStyleType",
      "DataSource": "REF_TO",
      "Unit": "STRING",
      "YFormat": "STRING",
      "TickCountY": "INT",
      "Thickness": "LREAL",
      "DrawConstant": "BOOL",
      "IsVisible": "BOOL",
      "LineJoin": "HMI.LineJoin",
      "Autoscale": "BOOL",
      "PointType": "HMI.PenPointType",
      "PointSize": "LREAL",
      "ShowAxis": "BOOL",
      "MainPenGroup": "BOOL",
      "GroupName": "STRING"
    },
    "DataType": "StructureType"
  },
  "HMI.TrendPens": {
    "TypeOfElementsName": "HMI.TrendPen",
    "Subranges": [
      0
    ],
    "DataType": "ArrayType"
  },
  "HMI.VerticalAlignType": {
    "Values": [
      "Top",
      "Center",
      "Bottom"
    ],
    "DisplayValues": [
      "Верх",
      "Центр",
      "Низ"
    ],
    "Indexes": [
      0,
      1,
      2
    ],
    "DataType": "EnumeratedType"
  },
  "INT": {
    "DataType": "ElementaryType"
  },
  "LINT": {
    "DataType": "ElementaryType"
  },
  "LREAL": {
    "DataType": "ElementaryType"
  },
  "PostgreSQL_VarsStruct": {
    "Fields": {
      "Name": "STRING",
      "ReadId": "LINT",
      "ReadPath": "STRING",
      "WriteId": "LINT",
      "WriteGlobalId": "LINT",
      "WritePath": "STRING"
    },
    "DataType": "StructureType"
  },
  "REF_TO": {
    "DataType": "ElementaryType"
  },
  "STRING": {
    "DataType": "ElementaryType"
  },
  "TIME": {
    "DataType": "ElementaryType"
  },
  "UDINT": {
    "DataType": "ElementaryType"
  },
  "UINT": {
    "DataType": "ElementaryType"
  },
  "USINT": {
    "DataType": "ElementaryType"
  }
}
}
}