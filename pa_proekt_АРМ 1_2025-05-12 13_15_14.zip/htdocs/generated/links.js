'use strict';
 export class Links { 
constructor(){
this.obj={} 
 this.windows =  
 {
  "59458": [
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "59591",
          "PropertyPath": "PanelDataSource",
          "DataType": "ARRAY [*] OF Локальная.struct_patest",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "59713",
        "PropertyPath": "",
        "DataType": "ARRAY [*] OF Локальная.struct_patest",
        "Type": "server",
        "DefaultValue": "{\r\n  \"id\": 0,\r\n  \"name\": \"\"\r\n}",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "65259",
          "PropertyPath": "PanelDataSource",
          "DataType": "ARRAY [*] OF Локальная.struct_patest_values",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "64329",
        "PropertyPath": "",
        "DataType": "ARRAY [*] OF Локальная.struct_patest_values",
        "Type": "server",
        "DefaultValue": "{\r\n  \"time\": \"0\",\r\n  \"value\": 0,\r\n  \"parameter_id\": 0,\r\n  \"id\": 0,\r\n  \"name\": \"\"\r\n}",
        "TaskNumber": 4,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "65383",
          "PropertyPath": "PanelDataSource",
          "DataType": "ARRAY [*] OF Локальная.struct_patest_values",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "64749",
        "PropertyPath": "",
        "DataType": "ARRAY [*] OF Локальная.struct_patest_values",
        "Type": "server",
        "DefaultValue": "{\r\n  \"time\": \"0\",\r\n  \"value\": 0,\r\n  \"parameter_id\": 0,\r\n  \"id\": 0,\r\n  \"name\": \"\"\r\n}",
        "TaskNumber": 4,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "65716",
          "PropertyPath": "PanelDataSource",
          "DataType": "ARRAY [*] OF Локальная.struct_patest_current_data",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "65783",
        "PropertyPath": "",
        "DataType": "ARRAY [*] OF Локальная.struct_patest_current_data",
        "Type": "server",
        "DefaultValue": "{\r\n  \"name\": \"\",\r\n  \"state_timestamp\": \"0\",\r\n  \"last_state\": false,\r\n  \"value_timestamp\": \"0\",\r\n  \"last_value\": 0\r\n}",
        "TaskNumber": 2,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "65981",
          "PropertyPath": "",
          "DataType": "INT",
          "Type": "server",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "65874",
        "PropertyPath": "Value",
        "DataType": "LREAL",
        "Type": "client",
        "DefaultValue": "1",
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "67146",
          "PropertyPath": "Value",
          "DataType": "LREAL",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        },
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "64229",
          "PropertyPath": "PensData.0.DataSource",
          "DataType": "REF_TO",
          "Type": "trend",
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "65571",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0,
        "TaskNumber": 0,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "67506",
          "PropertyPath": "Text",
          "DataType": "STRING",
          "Type": "client",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ItemId": "65654",
        "PropertyPath": "",
        "DataType": "LREAL",
        "Type": "server",
        "DefaultValue": 0,
        "TaskNumber": 2,
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "64003",
          "PropertyPath": "",
          "DataType": "BOOL",
          "Type": "server",
          "TaskNumber": 2,
          "HasBackward": false
        }
      ],
      "Source": {
        "ActionId": "59797",
        "ItemId": "59567",
        "PropertyPath": "Target",
        "DataType": "BOOL",
        "Type": "action",
        "DefaultValue": "False",
        "HasBackward": false
      }
    },
    {
      "Targets": [
        {
          "Operation": "move",
          "OneTime": false,
          "ItemId": "59716",
          "PropertyPath": "",
          "DataType": "INT",
          "Type": "server",
          "TaskNumber": 0,
          "HasBackward": false
        }
      ],
      "Source": {
        "ActionId": "60004",
        "ItemId": "59567",
        "PropertyPath": "Target",
        "DataType": "INT",
        "Type": "action",
        "DefaultValue": "",
        "HasBackward": false
      }
    }
  ]
} 
  
this.Items = { 
 };} 
 } 
 