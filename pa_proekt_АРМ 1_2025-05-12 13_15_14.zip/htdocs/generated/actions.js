export class Type {
    constructor() {
        this.type = {
  "59458": {
    "actions": {
      "59797": {
        "Duration": 0,
        "type": "Impulse"
      },
      "60004": {
        "Operation": "move",
        "Source": {
          "value": "1",
          "type": "STRING"
        },
        "Target": {
          "value": "0",
          "type": "INT"
        },
        "type": "SetParameterValue"
      }
    }
  }
}}
}