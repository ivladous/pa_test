
            import {Type} from './actions.js'
            import {DataTypes} from './datatypes.js'
            import {GlobalParameters} from './globalparams.js'
            import {Links} from './links.js'
            import {Permissions} from './permissions.js'
            import {ResourcesList} from './resourcesList.js'
            import {getSvgTemplate} from './svgtemplates.js'
            import {TaskList} from './TaskList.js'
            import {WinDefs} from './windefs.js'

            window.generated = {
                Type,
                DataTypes,
                GlobalParameters,
                Links,
                Permissions,
                ResourcesList,
                getSvgTemplate,
                TaskList,
                WinDefs
            }
        