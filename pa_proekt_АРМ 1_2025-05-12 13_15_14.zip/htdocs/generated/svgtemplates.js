'use strict'
export function getSvgTemplate(id) {return svgtemplates[id];}const svgtemplates =   
 {}; 